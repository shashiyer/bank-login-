import {Component,OnInit} from '@angular/core';
import {NgForm} from '@angular/forms'
import {User} from '../auth/login';
import {ActivatedRoute,Router} from '@angular/router'
import {HttpClient, HttpErrorResponse} from '@angular/common/http';
import { LoginService } from "src/auth/login.service";
// import {LoginService} from '../'

@Component({
    selector:'login',
    templateUrl:'./login.component.html',
    styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {
ngOnInit(): void
{  
}

constructor(private route:ActivatedRoute,private router:Router,private httpser:HttpClient,private loginservice:LoginService){}

user = new User();

        save(loginForm:NgForm)
    {
        console.log("Saved form "+this.user);
        // this.custservice.add(this.user).subscribe(data => console.log("success!!" , data),
        // error => console.log("Error!!",error))
        console.log('Save data' + JSON.stringify(loginForm.value));
    }
}