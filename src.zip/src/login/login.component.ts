import {Component,OnInit} from '@angular/core';
import {NgForm} from '@angular/forms'
import {User} from './login'
import {ActivatedRoute,Router} from '@angular/router'
import {HttpClient, HttpErrorResponse} from '@angular/common/http';
import {LoginService} from './login.service'

@Component({
    selector:'login',
    templateUrl:'./login.component.html'
})
export class LoginComponent implements OnInit {
ngOnInit(): void
{  
}

constructor(private route:ActivatedRoute,private router:Router,private httpser:HttpClient,private loginservice:LoginService){}

user = new User()

        save(loginForm:NgForm){
        console.log("saved form "+this.user);
        // this.custservice.add(this.user).subscribe(data => console.log("success!!" , data),
        // error => console.log("Error!!",error))
        console.log('save data' + JSON.stringify(loginForm.value))
    }
}