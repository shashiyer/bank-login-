import { CustomerListComponent } from '../customerlist/customerlist.component';
import { LoginComponent } from '../login/login.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RegisterComponent } from "../register/register.component";
import { NavbarComponent } from "src/navbar/navbar.component";
import { HomeComponent } from "src/home/home.component";


const routes: Routes = [
  {path:'login',component:LoginComponent},
  {path:'view',component:CustomerListComponent},
  {path:'register', component: RegisterComponent },
  {path: 'home', component: HomeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
