package com.example.Login.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.SecurityProperties.User;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Login.bean.Login;
import com.example.Login.dao.LoginDao;

@RestController

@CrossOrigin(origins ="http://localhost:4200")
@RequestMapping("/login")
public class LoginController
{
	@Autowired
	private LoginDao dao;
	
	
	@CrossOrigin(origins ="http://localhost:4200")
	@GetMapping("abc")
	
	public List<Login>  getLogin()
	{
		System.out.println("Received Request");
		return (List<Login>) dao.findAll();		
	}
}
