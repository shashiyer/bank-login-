export interface CustomerList{
    
    login_id:number;
    password:String;
}