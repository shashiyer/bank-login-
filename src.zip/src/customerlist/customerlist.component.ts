import { Router } from '@angular/router';
import { CustomerService } from './customerlist.service';
import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import {CustomerList} from './customerlist.interface';
// import { Ng2SearchPipeModule } from 'ng2-search-filter';
@Component({
    templateUrl:"./customer.component.html",
})

export class CustomerListComponent implements OnInit{
 
  title='Customer Lists'
  customerlist :CustomerList[]= [];
  errorMessage:string;

     constructor( private location: Location,private customerservice:CustomerService,private router:Router) { 
  }

ngOnInit(): void {
  this.customerservice.getCustomer().subscribe(
  customerlist =>{
  this.customerlist = customerlist;
},
error =>this.errorMessage = error

  );
}

deleteCustomer(id:number):void{
  this.customerservice.deleteCustomer(id).subscribe(
    data=>{console.log(data);
      this.customerservice.getCustomer().subscribe(data=>{
        this.customerlist=data;
      })
     
    },
     () => {
                    this.router.navigate(['/view']); 
                }
  )

}


}
