package com.example.Login.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;

import com.example.Login.bean.Login;
@Service
public interface LoginDao extends CrudRepository<Login, Integer> {

}
