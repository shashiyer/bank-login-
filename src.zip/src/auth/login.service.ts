import { Observable, throwError } from 'rxjs'
import {HttpClient, HttpHeaders,HttpErrorResponse} from '@angular/common/http';
import {User} from './login';
import { tap, catchError } from 'rxjs/operators';
import {Injectable} from '@angular/core';

const httpoptions = {
    headers : new HttpHeaders({ 'Content-Type': 'application/jason'})
};

@Injectable({
    providedIn:'root'})

export class LoginService{
    
    constructor(private httpser:HttpClient){}

    getAdmin(user:User)
    {
        return this.httpser.post("http://localhost:9092/login", user)
    }


    }
    // url="http"//localhost

