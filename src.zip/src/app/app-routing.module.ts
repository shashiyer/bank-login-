import { CustomerListComponent } from '../customerlist/customerlist.component';
import { LoginComponent } from '../login/login.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RegisterComponent } from "../register/register.component";


const routes: Routes = [
  {path:'add',component:LoginComponent},
  {path:'view',component:CustomerListComponent},
  {path:'register', component: RegisterComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
