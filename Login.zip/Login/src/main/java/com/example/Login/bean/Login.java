package com.example.Login.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="login")

public class Login
{
	@Id
	@GeneratedValue
	private int login_id;
	private String password;
	public void setLogin_id(int login_id) {
		this.login_id = login_id;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	public int getLogin_id() {
		return login_id;
	}
	
	public String getPassword() {
		return password;
	}
	
}
