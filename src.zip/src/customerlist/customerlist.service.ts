import { CustomerList } from './customerlist.interface';
import { HttpClient,HttpErrorResponse,HttpHeaders  } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import {tap, catchError} from 'rxjs/operators';
import { Injectable } from '@angular/core';
import {User} from 'src/addcustomer/addcustomer'


const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
 

@Injectable({
providedIn:'root'

})

export class CustomerService{

    //customerUrl = 'http://localhost:9090/customer';
    customerUrl='/customer';

    constructor(private httpSer:HttpClient) {
    }


    getCustomer():Observable<CustomerList[]>{
    
        return this.httpSer.get<CustomerList[]>("http://localhost:9090/customer/hello").pipe(
        tap(data => console.log('CustomerList : '+JSON.stringify(data))),
        catchError(this.handleError)
    );
    }

    private handleError(err:HttpErrorResponse){
        let errorMessage = '';
        if (err.error instanceof ErrorEvent) {
          errorMessage = `An error occurred: ${err.error.message}`;
        } else {
          errorMessage = `Server returned code: ${err.status}, error message is: ${err.message}`;
        }
        console.error(errorMessage);
        return throwError(errorMessage);
       
    }

    
     createCustomer(customer:any):Observable<any>{
       return this.httpSer.post('http://localhost:9090/customer/login',customer);
     }

     public deleteCustomer(id:number):Observable<any>{
       return this.httpSer.delete(`http://localhost:9090/login/delete/${id}`);
     }

}
