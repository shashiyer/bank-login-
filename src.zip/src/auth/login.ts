export class User
{
    public login_id : string 
    public password : string
}
   