export class User
{
    public login_id : number; 
    public password : string
}
   